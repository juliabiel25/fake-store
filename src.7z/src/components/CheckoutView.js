import { Link, useNavigate } from 'react-router-dom';

function AddedItems(props) {

	const removeItemFromCart = (item) => {
		const index = props.cart.findIndex(cartItem => cartItem._id === item._id);
		
		// single item of a type in cart
		if (props.cart[index].count == 1) {
			props.setCart([...props.cart.slice(0, index), ...props.cart.slice(index + 1)]);
		}
		// multiple items of a type in cart
		else {
			let updatedItem = props.cart[index]
			updatedItem.count -= 1;
			props.setCart([
				...props.cart.slice(0, index), 
				updatedItem, 
				...props.cart.slice(index + 1)
			]);
		}
	}

	return(props.cart.map((item) => (
			<div className='checkout-item' key={item._id}>
				<div className='checkout-item-img'></div>
				<div className='checkout-item-text'>
					<p>{item.name}</p>
					<p>{item.price}$</p>
					<p><small>Quantity: {item.count}</small></p>
					<button 
					className='btn-dark'
					onClick={()=>removeItemFromCart(item)}>
						Remove from cart
					</button>
				</div>
			</div>
	)))
}


function Checkout(props) {
	
	const navigate = useNavigate();

	const finilizePurchase = () => {
		// post request
		fetch('http://localhost:9000/items/rm/', {
			method: 'POST',
			headers: {
				'Accept': 'application/json',
				'Content-Type': 'application/json'
			},
			body: JSON.stringify(props.cart)
		})
		.then(res => {
			console.log('result:', res)
			if (res.ok) {
				console.log('HTTP request successful');
				props.setNotification({ type: 'success', message: 'Your purchase was finilised without issues!' });
			} else {
				console.log('HTTP request unsuccessful');
				props.setNotification({ type: 'error', message: 'Your purchase failed! The items might be out of stock' });
			}
			props.setCart([]);
			navigate('/', { replace: true });
			return res.json();
		})
		.catch(err => console.log(err));
	}

	const cancelPurchase = () => {
		props.setCart([]);
		navigate('/', { replace: true });
	}

	return(
        <div className="Checkout">
            <header className="App-header">
                <h1>Sklep z rzeczami</h1>
                <div className='side-nav'>
                    <Link to='/' className='btn-dark'>MAIN PAGE</Link>
                </div>
            </header>
            <div className='App-body checkout-cart'>
				<div className='cart-content'>
					<h2>Checkout</h2>
					<AddedItems cart={props.cart} setCart={props.setCart}/>
				</div>
				<div className='cart-control'>
					<button className='btn-dark' onClick={finilizePurchase}>Finilize</button>
					<button className='btn-dark' onClick={cancelPurchase}>Cancel</button>
				</div>
            </div>
        </div>		
	);
}

export default Checkout;