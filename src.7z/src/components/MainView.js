import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';

function Items(props) {
    const addItemToCart = (item) => {
        const index = props.cart.findIndex(cartItem => cartItem._id === item._id);
    
        // item not yet added to cart
        if (index == -1) {
            item.count = 1;
            props.setCart([...props.cart, item]);
        }
        // item already in cart
        else {
            let updatedItem = props.cart[index];
            updatedItem.count += 1;

            props.setCart([
                ...props.cart.slice(0, index), 
                updatedItem, 
                ...props.cart.slice(index + 1, props.cart.length)]);
        }
    }
    
	return(
        <div className='item-list'>
            {props.items.map((item) => (
                <div className='item' key={item._id}>
                    <div className='item-img'></div>
                    <p>{item.price}$</p>
                    {item.name}
                    <button 
                        className='btn-dark' 
                        onClick={() => addItemToCart(item) }>
                        Add to cart
                    </button>
                </div>)
            )}
        </div>
    )
}

function MainView(props) {
    const [items, setItems] = useState([]);
    const updateItems = () => (
        fetch('http://localhost:9000/items')
        .then(res => res.json())
        .then(res => setItems(Array.isArray(res) ? res : [res])));

    // update list of items on component mounting
    useEffect(() => {
        updateItems();
    }, []);  

	return(
        <div className="Main">
            <header className="App-header">
                <h1>Sklep z rzeczami</h1>
                <div className='side-nav'>
                    <Link to='/checkout' className='btn-dark'>CHECKOUT</Link>
                </div>
            </header>
            <div className='App-body'>
                <Items 
                    items={items} 
                    cart={props.cart} 
                    setCart={props.setCart} />
            </div>
        </div>		
	);
}

export default MainView;