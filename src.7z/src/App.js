import { useState, useEffect } from 'react';
import { BrowserRouter, Route, Routes } from 'react-router-dom';
import './App.css';
import './components/CheckoutView';
import Checkout from './components/CheckoutView';
import MainView from './components/MainView';
import {NotificationContainer, NotificationManager} from 'react-notifications';
import 'react-notifications/lib/notifications.css';


function createNotification(notification) {
	switch(notification.type) {
		case 'info':
			NotificationManager.info(notification.message, 'Info', 3000);
			break;
		case 'success':
			NotificationManager.success(notification.message, 'Success', 3000);
			break;
		case 'warning':
			NotificationManager.warning(notification.message, 'Warning', 3000);
			break;
		case 'error':
			NotificationManager.error(notification.message, 'Error', 3000);
			break;
	}
}

function App() {
	const [cart, setCart] = useState([]);
	const [notification, setNotification] = useState({type: '', message: ''})
  
	useEffect(() => {
		createNotification(notification);	
	}, [notification])
	
  	return (
		<div className='App'>
			<NotificationContainer />
			<BrowserRouter>
				<Routes>
					<Route path='/' element={
						<MainView 
							cart={cart} 
							setCart={setCart} 
							setNotification={setNotification}
						/>
					}>
					</Route>
					<Route path='/checkout' element={
						<Checkout 
							cart={cart} 
							setCart={setCart}
							setNotification={setNotification}
						/>
					}>
					</Route>
				</Routes>
			</BrowserRouter>
		</div>		
  	);
}

export default App;
